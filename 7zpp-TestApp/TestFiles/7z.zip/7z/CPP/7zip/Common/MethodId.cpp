// MethodId.cpp

#include "StdAfx.h"
